// Checkout Component

const { useState, useContext, useEffect } = React;
const { useNavigate, Link, useLocation } = window.ReactRouterDOM;

const Checkout = () => {
  const { cartItems, clearCart } = useContext(window.CartContext);
  const navigate = useNavigate();
  const location = useLocation();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    cardName: '',
    cardNumber: '',
    expDate: '',
    cvv: ''
  });
  
  const [loading, setLoading] = useState(false);
  const [showSummaryModal, setShowSummaryModal] = useState(false);
  
  // Check authentication status when component mounts
  useEffect(() => {
    fetch('/api/auth/status')
      .then(response => response.json())
      .then(data => {
        setIsAuthenticated(data.authenticated);
      })
      .catch(error => {
        console.error('Error checking auth status:', error);
        setIsAuthenticated(false);
      });
  }, []);
  
  // Initialize Bootstrap modal
  useEffect(() => {
    // This creates the modal instance when the component is mounted
    const summaryModal = new bootstrap.Modal(document.getElementById('orderSummaryModal'), {
      keyboard: true,
      backdrop: true
    });
    
    // Cleanup function to hide modal when component unmounts
    return () => {
      if (summaryModal && summaryModal._element) {
        summaryModal.hide();
      }
    };
  }, []);
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!isAuthenticated) {
      // Store the current path in sessionStorage for redirect after login
      sessionStorage.setItem('redirectAfterAuth', '/checkout');
      navigate('/auth/login');
      return;
    }
    
    if (cartItems.length === 0) {
      alert('Your cart is empty');
      navigate('/products');
      return;
    }
    
    setLoading(true);
    
    // Submit order to the backend
    axios.post('/api/checkout', {
      items: cartItems,
      customer: formData
    })
      .then(response => {
        // Clear the cart
        clearCart();
        
        // Show success message and redirect to orders page
        setLoading(false);
        alert('Order placed successfully! You can view your order details in your orders page.');
        navigate('/orders');
      })
      .catch(error => {
        console.error('Error placing order:', error);
        setLoading(false);
        alert('Error placing order. Please try again.');
      });
  };
  
  if (cartItems.length === 0) {
    return (
      <div className="container my-5">
        <div className="text-center py-5">
          <div className="mb-4">
            <i className="bi bi-cart text-muted" style={{fontSize: '4rem'}}></i>
          </div>
          <h3 className="mb-3">Your cart is empty</h3>
          <p className="text-muted mb-4">You need to add items to your cart before checkout.</p>
          <Link to="/products" className="btn btn-primary">
            Start Shopping
          </Link>
        </div>
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return (
      <div className="container my-5">
        <div className="text-center py-5">
          <div className="mb-4">
            <i className="bi bi-lock text-primary" style={{fontSize: '4rem'}}></i>
          </div>
          <h3 className="mb-3">Sign In Required</h3>
          <p className="text-muted mb-4">Please sign in or create an account to place your order.</p>
          <div className="d-flex justify-content-center gap-3">
            <Link 
              to="/auth/login" 
              className="btn btn-primary"
              onClick={() => sessionStorage.setItem('redirectAfterAuth', '/checkout')}
            >
              Sign In
            </Link>
            <Link 
              to="/auth/register" 
              className="btn btn-outline-primary"
              onClick={() => sessionStorage.setItem('redirectAfterAuth', '/checkout')}
            >
              Create Account
            </Link>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container my-5">
      <h1 className="mb-4">Checkout</h1>
      <div className="row">
        <div className="col-lg-8">
          <form onSubmit={handleSubmit}>
            {/* Shipping Information */}
            <div className="checkout-section mb-4">
              <h3>Shipping Information</h3>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label htmlFor="firstName" className="form-label">First Name</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    id="firstName" 
                    name="firstName" 
                    value={formData.firstName} 
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="col-md-6 mb-3">
                  <label htmlFor="lastName" className="form-label">Last Name</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    id="lastName" 
                    name="lastName" 
                    value={formData.lastName} 
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
              
              <div className="mb-3">
                <label htmlFor="email" className="form-label">Email</label>
                <input 
                  type="email" 
                  className="form-control" 
                  id="email" 
                  name="email" 
                  value={formData.email} 
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="mb-3">
                <label htmlFor="address" className="form-label">Address</label>
                <input 
                  type="text" 
                  className="form-control" 
                  id="address" 
                  name="address" 
                  value={formData.address} 
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="row">
                <div className="col-md-4 mb-3">
                  <label htmlFor="city" className="form-label">City</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    id="city" 
                    name="city" 
                    value={formData.city} 
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="col-md-4 mb-3">
                  <label htmlFor="state" className="form-label">State</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    id="state" 
                    name="state" 
                    value={formData.state} 
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="col-md-4 mb-3">
                  <label htmlFor="zipCode" className="form-label">Zip Code</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    id="zipCode" 
                    name="zipCode" 
                    value={formData.zipCode} 
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
            </div>
            
            {/* Payment Information */}
            <div className="checkout-section mb-4">
              <h3>Payment Information</h3>
              <div className="mb-3">
                <label htmlFor="cardName" className="form-label">Name on Card</label>
                <input 
                  type="text" 
                  className="form-control" 
                  id="cardName" 
                  name="cardName" 
                  value={formData.cardName} 
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="mb-3">
                <label htmlFor="cardNumber" className="form-label">Card Number</label>
                <input 
                  type="text" 
                  className="form-control" 
                  id="cardNumber" 
                  name="cardNumber" 
                  value={formData.cardNumber} 
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label htmlFor="expDate" className="form-label">Expiration Date</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    id="expDate" 
                    name="expDate" 
                    placeholder="MM/YY"
                    value={formData.expDate} 
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="col-md-6 mb-3">
                  <label htmlFor="cvv" className="form-label">CVV</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    id="cvv" 
                    name="cvv" 
                    value={formData.cvv} 
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
            </div>
            
            <button 
              type="submit" 
              className="btn btn-primary btn-lg w-100"
              disabled={loading}
            >
              {loading ? (
                <>
                  <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                  Processing...
                </>
              ) : (
                'Place Order'
              )}
            </button>
          </form>
        </div>
        
        {/* Order Summary */}
        <div className="col-lg-4">
          <div className="card">
            <div className="card-body">
              <h3 className="card-title">Order Summary</h3>
              <div className="d-flex justify-content-between mb-2">
                <span>Subtotal</span>
                <span>${calculateTotal().toFixed(2)}</span>
              </div>
              <div className="d-flex justify-content-between mb-2">
                <span>Shipping</span>
                <span>$4.99</span>
              </div>
              <div className="d-flex justify-content-between mb-2">
                <span>Tax (6%)</span>
                <span>${(calculateTotal() * 0.06).toFixed(2)}</span>
              </div>
              <hr />
              <div className="d-flex justify-content-between mb-3">
                <strong>Total</strong>
                <strong>${(calculateTotal() + 4.99 + (calculateTotal() * 0.06)).toFixed(2)}</strong>
              </div>
              
              <div className="order-items">
                <h4 className="h5 mb-3">Items</h4>
                {cartItems.map(item => (
                  <div key={item.id} className="d-flex justify-content-between mb-2">
                    <span>{item.name} x {item.quantity}</span>
                    <span>${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Make the Checkout component available globally
window.Checkout = Checkout;
